------------------
Freebie: Free Vector Web Icons (91 Icons)
Designed by August Interactive (http://www.augustinteractive.com/) and lead UI designer�Tomas Gajar 
------------------

Dear Friends,

Thank you for downloading this file. This freebie has been brought to you by SmashingMagazine.com. You can freely use it for both your private and commercial projects, including software, online services, templates and themes. The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites other than SmashingMagazine.com and AugustInteractive.com. Please link to the article in which this freebie was released if you would like to spread the word.

Yours sincerely,
Smashing Magazine Team
www.smashingmagazine.com





